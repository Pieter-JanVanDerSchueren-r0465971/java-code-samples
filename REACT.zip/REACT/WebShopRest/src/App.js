import React, {Component} from 'react';
import './App.css';
import $ from 'jquery';

class App extends Component {
    constructor(props) {
        super(props);
        this.state = {
            products: []
        }
    }

    componentDidMount() {
        setInterval(() => fetch('http://193.191.177.8:10388/webshop-rest/rest/products.htm')
            .then(function (response) {
                return response.json()
            }).then((data) => {
                this.setState({
                    products: data
                })
            }), 1000)
    }

    editProduct(product) {
        document.getElementById("editProductId").value = product.productId;
        document.getElementById("editName").value = product.name;
        document.getElementById("editDescription").value = product.description;
        document.getElementById("editPrice").value = product.price;
    }

    deleteProduct(product) {
        $.ajax({
            url: 'http://193.191.177.8:10388/webshop-rest/rest/delete/' + product.productId +
            '.htm',    //Your api url
            type:
                'DELETE',   //type is any HTTP method
        })
    }

    editProductREST() {
        let p = {
            "productId": document.getElementById("editProductId").value,
            "name": document.getElementById("editName").value,
            "description": document.getElementById("editDescription").value,
            "price": document.getElementById("editPrice").value
        };

        $.ajax({
            url: 'http://193.191.177.8:10388/webshop-rest/rest/edit.htm',    //Your api url
            type: 'PUT',   //type is any HTTP method
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            data: JSON.stringify(p)     //Data as js object
        })
    }

    createProductREST() {
        let p = {
            "name": document.getElementById("createName").value,
            "description": document.getElementById("createDescription").value,
            "price": document.getElementById("createPrice").value
        };

        $.ajax({
            url: 'http://193.191.177.8:10388/webshop-rest/rest/add.htm',    //Your api url
            type: 'POST',   //type is any HTTP method
            headers: {
                'Accept': 'application/json',
                'Content-Type': 'application/json'
            },
            data: JSON.stringify(p)     //Data as js object
        })
    }

    render() {
        let products = this.state.products;

        return <div className="App">

            <table>
                <tbody>
                    <tr>
                        <th>ProductName</th>
                        <th>ProductDescription</th>
                        <th>ProductPrice</th>
                        <th>EditProduct</th>
                        <th>DeleteProduct</th>
                    </tr>

                    {
                        products.map((product, index) => (
                            <tr key={index}>
                                <td key={product.name + index}>{product.name}</td>
                                <td key={product.description + index}>{product.description}</td>
                                <td key={product.price + index}>{product.price}</td>
                                <td key={"edit" + index}><button onClick={() => this.editProduct(product)}>Edit</button></td>
                                <td key={"delete" + index}><button onClick={() => this.deleteProduct(product)}>Delete</button></td>
                            </tr>
                        ))
                    }
                </tbody>
            </table>
            <h2>Create form</h2>
            <form>
                <p>Name</p><input id="createName" type="text"/>
                <p>Description</p><input id="createDescription" type="text"/>
                <p>Price</p><input id="createPrice" type="number" step="0.01"/>
                <br></br><br></br>
                <input onClick={() => this.createProductREST()} type="submit" value="Submit"/>
            </form>

            <h2>Edit form</h2>
            <form>
                <input id="editProductId" type="hidden"/>
                <p>Name</p><input id="editName" type="text"/>
                <p>Description</p><input id="editDescription" type="text"/>
                <p>Price</p><input id="editPrice" type="number" step="0.01"/>
                <br></br><br></br>
                <input onClick={() => this.editProductREST()} type="submit" value="Submit"/>
            </form>
        </div>;
    }
}

export default App;
