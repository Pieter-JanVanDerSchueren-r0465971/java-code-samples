package be.ucll.application.domain;

import static org.junit.Assert.*;

import org.junit.Test;

public class ProductTest {
    private Product product1 = new Product(101, "Banaan", "Fruit", 5.33);
    private Product product2 = new Product(102, "Broccoli", "Groente", 8.25);
    private Product product3 = new Product(103, "Roos", "Bloem", 13.50);

    @Test
    public void constructorTest_alles_is_correct_gegeven_en_werkt_correct() {
        Product product4 = new Product(104, "Chocolade reep", "Snack", 13.13);
        assertEquals(product4.getProductId(), 104);
        assertEquals(product4.getName(), "Chocolade reep");
        assertEquals(product4.getDescription(), "Snack");
        assertEquals(product4.getPrice(), 13.13);
    }

    @Test(expected = DomainException.class)
    public void setProductId_0_geeft_DomainException() {
        product1.setProductId(0);
    }

    @Test(expected = DomainException.class)
    public void setProductId_negatief_geeft_DomainException() {
        product2.setProductId(-5);
    }

    @Test(expected = DomainException.class)
    public void setProductId_groter_dan_10000_geeft_DomainException() {
        product3.setProductId(10001);
    }

    @Test(expected = DomainException.class)
    public void setName_met_Null_geeft_DomainException() {
        product1.setName(null);
    }

    @Test(expected = DomainException.class)
    public void setName_met_lege_String_geeft_DomainException() {
        product1.setName("");
    }

    @Test(expected = DomainException.class)
    public void setDescription_met_Null_geeft_DomainException() {
        product1.setDescription(null);
    }

    @Test(expected = DomainException.class)
    public void setDescription_met_lege_String_geeft_DomainException() {
        product1.setDescription("");
    }

    @Test(expected = DomainException.class)
    public void setPrijs_0_geeft_DomainException() {
        product1.setPrice(0);
    }

    @Test(expected = DomainException.class)
    public void setPrijs_negatief_geeft_DomainException() {
        product2.setPrice(-5);
    }

    @Test()
    public void setPrijs_kommagetal_x_na_de_komma_wordt_correct_afgerond_geeft_DomainException() {
        product2.setPrice(55.555);
        assertEquals(product2.getPrice(), 55.56);
        product2.setPrice(55.554);
        assertEquals(product2.getPrice(), 55.55);
        product2.setPrice(55.5);
        assertEquals(product2.getPrice(), 55.50);
        product2.setPrice(55);
        assertEquals(product2.getPrice(), 55.00);
    }
}