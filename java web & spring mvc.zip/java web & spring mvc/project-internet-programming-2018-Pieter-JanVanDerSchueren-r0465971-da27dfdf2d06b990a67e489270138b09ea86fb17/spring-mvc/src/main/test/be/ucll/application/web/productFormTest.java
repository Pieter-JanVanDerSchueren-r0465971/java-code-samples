package be.ucll.application.web;

import static org.junit.Assert.assertEquals;

import be.ucll.application.db.ShopFacade;
import be.ucll.application.domain.Product;
import org.junit.*;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;


public class productFormTest {
    private WebDriver driver;
    private static ShopFacade shop = new ShopFacade("sql");
    private static ShopFacade backupShop = new ShopFacade("memory");

    @BeforeClass
    public static void voordien() {
        for (Product product : shop.getProducts()) {
            backupShop.addProduct(product);
        }
        shop.resetDb();
    }

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
        driver = new ChromeDriver();
        driver.get("http://localhost:8080/Application");
    }

    @After
    public void clean() {
        shop.resetDb();
        driver.quit();
    }

    private void fillOutField(String name, String value) {
        WebElement field = driver.findElement(By.id(name));
        field.clear();
        field.sendKeys(value);
    }

    private void submitForm(String name, String description, String price) {
        fillOutField("name", name);
        fillOutField("description", description);
        fillOutField("price", price);
        WebElement button = driver.findElement(By.id("submit"));
        button.click();
    }

    @Test
    public void testCreateProductCorrect() {
        WebElement link = driver.findElement(By.id("createLink"));
        link.click();
        submitForm("testNaam", "testBeschrijving", "50");
        WebElement name = driver.findElement(By.id("1name"));
        assertEquals("testNaam", name.getText());
        WebElement description = driver.findElement(By.id("1description"));
        assertEquals("testBeschrijving", description.getText());
        WebElement price = driver.findElement(By.id("1price"));
        assertEquals("50.0", price.getText());
    }

    @Test
    public void testEditProductCorrect() {
        WebElement link = driver.findElement(By.id("createLink"));
        link.click();
        submitForm("testNaam", "testBeschrijving", "50");
        link = driver.findElement(By.id("1edit"));
        link.click();
        submitForm("testNaam2", "testBeschrijving2", "52");
        WebElement name = driver.findElement(By.id("1name"));
        assertEquals("testNaam2", name.getText());
        WebElement description = driver.findElement(By.id("1description"));
        assertEquals("testBeschrijving2", description.getText());
        WebElement price = driver.findElement(By.id("1price"));
        assertEquals("52.0", price.getText());
    }

    @Test
    public void testCreateProductErrors() {
        WebElement link = driver.findElement(By.id("createLink"));
        link.click();
        submitForm("   ", "   ", "0");
        WebElement name = driver.findElement(By.id("nameError"));
        assertEquals("The name cannot be empty!", name.getText());
        WebElement description = driver.findElement(By.id("descriptionError"));
        assertEquals("The description cannot be empty!", description.getText());
        WebElement price = driver.findElement(By.id("priceError"));
        assertEquals("The price must be greater than 0 and lesser than 10000000!", price.getText());
    }

    @Test
    public void testEditProductErrors() {
        WebElement link = driver.findElement(By.id("createLink"));
        link.click();
        submitForm("testNaam", "testBeschrijving", "50");
        link = driver.findElement(By.id("1edit"));
        link.click();
        submitForm("   ", "   ", "0");
        WebElement name = driver.findElement(By.id("nameError"));
        assertEquals("The name cannot be empty!", name.getText());
        WebElement description = driver.findElement(By.id("descriptionError"));
        assertEquals("The description cannot be empty!", description.getText());
        WebElement price = driver.findElement(By.id("priceError"));
        assertEquals("The price must be greater than 0 and lesser than 10000000!", price.getText());
    }

    @AfterClass
    public static void nadien() {
        for (Product product : backupShop.getProducts()) {
            shop.addProduct(product);
        }
        shop.quit();
    }

}
