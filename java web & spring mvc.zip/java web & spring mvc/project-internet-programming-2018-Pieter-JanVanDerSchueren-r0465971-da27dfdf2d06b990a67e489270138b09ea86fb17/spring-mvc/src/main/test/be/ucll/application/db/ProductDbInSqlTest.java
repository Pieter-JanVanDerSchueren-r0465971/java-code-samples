package be.ucll.application.db;

import static org.junit.Assert.*;

import be.ucll.application.domain.Product;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import java.util.ArrayList;

public class ProductDbInSqlTest {
    private ShopFacade shop = new ShopFacade("memory");
    ArrayList<Product> testLijst = new ArrayList<Product>();
    private Product product1 = new Product("Banaan", "Fruit", 5.33);
    private Product product2 = new Product("Broccoli", "Groente", 8.25);
    private Product product4 = new Product(1, "Ananas", "Fruit", 6.66);
    private int count = 0;

    @Before
    public void setup() {
        try {
            shop.resetDb();
        } catch (DbException e) {
        }
        shop.getProductDb().add(product1);
        shop.getProductDb().add(product2);
        testLijst.add(product1);
        testLijst.add(product2);
    }

    @Test
    public void producten_Toevoegen_Werkt() {
        Product product3 = new Product("Roos", "Bloem", 13.50);
        testLijst.add(product3);
        shop.getProductDb().add(product3);
        int i = 0;
        Boolean works = true;
        for (Product product : shop.getProductDb().getAll()) {
            if (!shop.getProductDb().getAll().get(i).getName().equals(testLijst.get(i).getName()) ||
                    !shop.getProductDb().getAll().get(i).getDescription().equals(testLijst.get(i).getDescription()) ||
                    shop.getProductDb().getAll().get(i).getPrice() != testLijst.get(i).getPrice()) {
                works = false;
            }
            i++;
        }
        assertEquals(true, works);
        count++;
    }

    @Test(expected = DbException.class)
    public void producten_Verwijderen_Werkt() {
        int i = 1;
        shop.getProductDb().delete(i);
        shop.getProductDb().get(i);
        count++;
    }

    @Test
    public void producten_Wijzigen_Werkt() {
        shop.getProductDb().update(product4);
        assertEquals(product4.getName(), shop.getProductDb().get(product4.getProductId()).getName());
        assertEquals(product4.getDescription(), shop.getProductDb().get(product4.getProductId()).getDescription());
        assertEquals(product4.getPrice(), shop.getProductDb().get(product4.getProductId()).getPrice());
        count++;
    }

    @Test
    public void producten_Berekende_Waarde_Werkt() {
        assertEquals(13.58, shop.getProductDb().calculatedValue());
        count++;
    }

    @After
    public void quit() {
        testLijst.clear();
        shop.resetDb();
        if (count == 4) {
            try {
                shop.quit();
            } catch (DbException e) {
            }
        }
    }
}
