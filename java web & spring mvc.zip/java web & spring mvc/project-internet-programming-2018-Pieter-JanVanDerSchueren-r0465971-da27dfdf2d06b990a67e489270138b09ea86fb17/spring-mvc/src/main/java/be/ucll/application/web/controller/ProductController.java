package be.ucll.application.web.controller;

import be.ucll.application.db.ShopFacade;
import be.ucll.application.domain.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.ReloadableResourceBundleMessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/product")
public class ProductController {
    private final ShopFacade shop;

    public ProductController(@Autowired ShopFacade shop) {
        this.shop = shop;
    }

    @RequestMapping(method = RequestMethod.GET)
    public ModelAndView getProducts() {
        return new ModelAndView("read", "products", shop.getProducts());
    }

    @RequestMapping(value = "/create", method = RequestMethod.GET)
    public ModelAndView getNewForm() {
        return new ModelAndView("productForm", "product", new Product());
    }

    @RequestMapping(method = RequestMethod.POST)
    public String submit(Product product, BindingResult result) {
        if (result.hasErrors()) {
            System.out.println(result.getAllErrors().toString());
            return "productForm";
        }
        shop.addProduct(product);
        return "redirect:/product.htm";
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public String update(Product product, BindingResult result) {
        if (result.hasErrors()) {
            System.out.println(result.getAllErrors().toString());
            return "productForm";
        }
        shop.updateProduct(product);
        return "redirect:/product.htm";
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ModelAndView getEditForm(@PathVariable int id) {
        return new ModelAndView("productForm", "product", shop.getProduct(id));
    }

    @RequestMapping(value = "/{id}/delete", method = RequestMethod.GET)
    public ModelAndView getDeletePage(@PathVariable int id) {
        return new ModelAndView("delete", "product", shop.getProduct(id));
    }

    @RequestMapping(value = "/deleteConfirmation", method = RequestMethod.POST, params = "submit")
    public String deleteConfirmation(Product product, BindingResult result, @RequestParam(value = "submit") String submit) {
        if (submit.equals("ja")) {
            shop.deleteProduct(product.getProductId());
        }
        return "redirect:/product.htm";
    }

    @Bean
    public MessageSource messageSource () {
        ReloadableResourceBundleMessageSource messageSource = new ReloadableResourceBundleMessageSource();
        messageSource.setBasename("classpath:validationMessages");
        return messageSource;
    }

}
