package be.ucll.application.db;

import java.util.List;

import be.ucll.application.domain.Product;

public class ShopFacade {
    private ProductDbInterface productDb;
    DbFactory factory = new DbFactory();

    public ShopFacade(String choice) {
        if (!choice.equals("file") && !choice.equals("memory") && !choice.equals("sql")) {
            throw new DbException("De input moet " + "\"file\", " + "\"memory\" of " + "\"sql\"" + " zijn.");
        }
        productDb = factory.getStrategy(choice);
    }

    public void setStrategy(String choice) {
        if (!choice.equals("file") && !choice.equals("memory") && !choice.equals("sql")) {
            throw new DbException("De input moet " + "\"file\", " + "\"memory\" of " + "\"sql\"" + " zijn.");
        }
        DbFactory factory = new DbFactory();
        productDb = factory.getStrategy(choice);
    }

    public Product getProduct(int productId) {
        return getProductDb().get(productId);
    }

    public List<Product> getProducts() {
        return getProductDb().getAll();
    }

    public void addProduct(Product product) {
        getProductDb().add(product);
    }

    public void updateProduct(Product product) {
        getProductDb().update(product);
    }

    public void deleteProduct(int id) {
        try {
            getProductDb().delete(id);
        } catch (Exception e) {
            throw new DbException("Verkeerde input voor id!" + "\n" + e.getMessage());
        }
    }

    public ProductDbInterface getProductDb() {
        return productDb;
    }

    public void schrijfUit() {
        if (!this.getProductDb().getClass().getName().equals("be.ucll.application.db.ProductDbInFile")) {
            throw new DbException("Niet het jusite dbtype!");
        }
        ProductDbInFile db = (ProductDbInFile) this.getProductDb();
        try {
            db.schrijfUit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void toConsole() {
        try {
            this.getProductDb().toConsole();
        } catch (NullPointerException e) {
            throw new DbException("Lege db!");
        }
    }

    public double calculatedValue() {
        return this.getProductDb().calculatedValue();
    }

    public void deleteAll() {
        for (Product product : getProductDb().getAll()) {
            this.deleteProduct((product.getProductId()));
        }
    }

    public void resetDb() {
        this.deleteAll();
        getProductDb().resetDb();
    }

    public void quit() {
        try {
            getProductDb().quit();
        } catch (DbException e) {
            throw new DbException(e.getMessage());
        }
    }
}