package be.ucll.application.db;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import be.ucll.application.domain.Product;

public class ProductDbInMemory implements ProductDbInterface {
    private Map<Integer, Product> records = new HashMap<Integer, Product>();
    private static int idCount;

    public ProductDbInMemory() {
        idCount = 0;
    }

    public Product get(int id) {
        if (id < 0) {
            throw new DbException("No valid id given");
        }
        if (records.get(id) == null) {
            throw new DbException("No such item id in db!");
        }
        return records.get(id);
    }

    public List<Product> getAll() {
        if (records.values().size() == 0) {
            throw new DbException("Lege db!");
        }
        return new ArrayList<Product>(records.values());
    }

    public void add(Product product) {
        if (product == null) {
            throw new DbException("No product given");
        }
        idCount = idCount + 1;
        product.setProductId(idCount);
        if (records.containsKey(product.getProductId())) {
            throw new DbException("Product already exists");
        }
        records.put(product.getProductId(), product);
    }

    public void update(Product product) {
        if (product == null) {
            throw new DbException("No product given");
        }
        if (!records.containsKey(product.getProductId())) {
            throw new DbException("No product found");
        }
        records.put(product.getProductId(), product);
    }

    public void delete(int id) {
        if (id < 0) {
            throw new DbException("No valid id given");
        }
        if (records.get(id) == null) {
            throw new DbException("No such item id in db!");
        }
        records.remove(id);
    }

    @Override
    public double calculatedValue() {
        double som = 0;
        for (Product product : this.getAll()) {
            som = som + product.getPrice();
        }
        return som;
    }

    @Override
    public void toConsole() {
        if (this.getAll() == null) {
            throw new DbException("Geen db.");
        }

        for (int i = 0; i < this.getAll().size(); i++)
            System.out.print(this.getAll().get(i));
    }

    @Override
    public void resetDb() {
        this.idCount = 0;
    }

    @Override
    public void quit() {
        this.resetDb();
    }
}