package be.ucll.application.db;

public class DbFactory {
    private ProductDbInterface dbtype;

    public DbFactory() {

    }

    public ProductDbInterface getStrategy(String choice) {
        if (choice == null || choice.trim().isEmpty()) {
            throw new DbException("Verkeerde keuze!");
        }
        switch (choice) {
            case "memory":
                dbtype = new ProductDbInMemory();
                break;
            case "file":
                dbtype = new ProductDbInFile();
                break;
            case "sql":
                dbtype = new ProductDbInSql();
                break;
            default:
                throw new DbException("Verkeerde keuze!");
        }
        return dbtype;
    }
}