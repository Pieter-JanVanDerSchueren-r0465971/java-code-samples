package be.ucll.application.domain;

import java.io.Serializable;

public class Product implements Serializable {
    private int productId;
    private String name;
    private String description;
    private double price;

    public Product() {

    }

    public Product(int productId, String name, String description, double d) {
        setProductId(productId);
        setName(name);
        setDescription(description);
        setPrice(d);
    }

    public Product(String name, String description, double d) {
        setName(name);
        setDescription(description);
        setPrice(d);
    }

    public Product(String productId, String name, String description, String d) {
        try {
            setProductId(Integer.parseInt(productId));
        } catch (Exception e) {
            throw new DomainException("Verkeerde input voor id!" + "\n" + e.getMessage());
        }
        setName(name);
        setDescription(description);
        try {
            setPrice((double) Double.parseDouble(d));
        } catch (Exception e) {
            throw new DomainException("Verkeerde input voor prijs!" + "\n" + e.getMessage());
        }
    }

    public Product(String name, String description, String d) {
        setName(name);
        setDescription(description);
        try {
            setPrice((double) Double.parseDouble(d));
        } catch (Exception e) {
            throw new DomainException("Verkeerde input voor prijs!" + "\n" + e.getMessage());
        }
    }

    public int getProductId() {
        return productId;
    }

    public void setProductId(int productId) {
        if (10000 < productId || productId <= 0) {
            throw new DomainException("De productId moet een waarde tussen tussen 1 en 10000 zijn!");
        }
        this.productId = productId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new DomainException("De naam String mag niet leeg of null zijn!");
        }
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        if (description == null || description.trim().isEmpty()) {
            throw new DomainException("De description String mag niet leeg of null zijn!");
        }
        this.description = description;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        if (price <= 0) {
            throw new DomainException("De prijs moet groter zijn dan 0!");
        }
        if (price > 10000000) {
            throw new DomainException("De prijs moet kleiner zijn dan 10000000!");
        }
        double value = price * 100;
        int round = (int) Math.round(value);
        price = (double) round / 100;
        this.price = price;
    }

    public void setPrice(String price) {
        double dubbel;
        if (price == null || price.trim().isEmpty()) {
            throw new DomainException("Slechte input voor double!");
        }
        try {
            dubbel = Double.parseDouble(price);
        } catch (Exception e) {
            throw new DomainException(e.getMessage());
        }
        this.setPrice(dubbel);
    }

    @Override
    public String toString() {
        return getProductId() + " " + getName() + ": " + getDescription() + " - " + getPrice() + "\n";
    }
}