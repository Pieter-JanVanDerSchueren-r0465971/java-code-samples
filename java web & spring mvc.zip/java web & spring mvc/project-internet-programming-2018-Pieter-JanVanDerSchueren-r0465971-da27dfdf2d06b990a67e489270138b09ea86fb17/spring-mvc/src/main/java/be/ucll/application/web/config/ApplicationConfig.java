package be.ucll.application.web.config;

import be.ucll.application.db.ShopFacade;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class ApplicationConfig {
    @Bean
    public ShopFacade shop(){
        return new ShopFacade("sql");
    }
}