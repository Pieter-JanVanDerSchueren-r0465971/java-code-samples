package be.ucll.application.db;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import be.ucll.application.domain.DomainException;
import be.ucll.application.domain.Product;

public class ProductDbInFile implements ProductDbInterface {
    private Map<Integer, Product> records;
    private static int staticId = 0;

    public ProductDbInFile() {
        records = new HashMap<Integer, Product>();
        try {
            this.leesIn();
        } catch (Exception e) {
            e.printStackTrace();
        }
        staticId = records.size();
    }

    public Product get(int id) {
        if (id < 0) {
            throw new DbException("No valid id given");
        }
        if (records.get(id) == null) {
            throw new DbException("No such item id in db!");
        }
        return records.get(id);
    }

    public List<Product> getAll() {
        return new ArrayList<Product>(records.values());
    }

    public void add(Product product) {
        if (product == null) {
            throw new DbException("No product given");
        }
        staticId = staticId + 1;
        product.setProductId(staticId);
        if (records.containsKey(product.getProductId())) {
            throw new DbException("Product already exists");
        }
        records.put(product.getProductId(), product);
        try {
            this.schrijfUit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void update(Product product) {
        if (product == null) {
            throw new DbException("No product given");
        }
        if (!records.containsKey(product.getProductId())) {
            throw new DbException("No product found");
        }
        records.put(product.getProductId(), product);
        try {
            this.schrijfUit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void delete(int id) {
        if (id < 0) {
            throw new DbException("No valid id given");
        }
        if (records.get(id) == null) {
            throw new DbException("No such item id in db!");
        }
        records.remove(id);
        try {
            this.schrijfUit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public double calculatedValue() {
        double som = 0;
        for (Product product : this.getAll()) {
            som = som + product.getPrice();
        }
        return som;
    }

    public void schrijfUit() throws Exception {
        FileOutputStream list = new FileOutputStream("file.txt");
        ObjectOutputStream os = new ObjectOutputStream(list);
        List<Product> lijst = this.getAll();
        if (lijst != null && !lijst.isEmpty()) {
            try {
                os.writeObject(this.getAll());
            } catch (DomainException e) {
                e.printStackTrace();
            }
        }
        os.close();
    }

    public void leesIn() throws Exception {
        FileInputStream list = new FileInputStream("file.txt");
        ObjectInputStream is = new ObjectInputStream(list);
        ArrayList<Product> lijst = (ArrayList<Product>) is.readObject();
        if (lijst != null && !lijst.isEmpty()) {
            try {
                for (Product product : lijst) {
                    records.put(product.getProductId(), product);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        is.close();
    }

    @Override
    public void toConsole() {
        for (int i = 0; i < this.getAll().size(); i++)
            System.out.print(this.getAll().get(i).toString());
    }

    public void resetDb() {
        this.staticId = 0;
    }

    @Override
    public void quit() {
        try {
            this.schrijfUit();
            this.resetDb();
        } catch (Exception e) {
            throw new DbException(e.getMessage());
        }
    }
}