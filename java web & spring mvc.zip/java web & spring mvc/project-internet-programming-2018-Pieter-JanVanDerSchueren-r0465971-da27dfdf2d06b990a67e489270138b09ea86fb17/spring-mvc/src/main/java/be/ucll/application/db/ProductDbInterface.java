package be.ucll.application.db;

import java.util.List;

import be.ucll.application.domain.Product;

public interface ProductDbInterface {
    Product get(int id);

    List<Product> getAll();

    void add(Product p);

    void update(Product p);

    void delete(int id);

    double calculatedValue();

    void toConsole();

    void resetDb();

    void quit();
}