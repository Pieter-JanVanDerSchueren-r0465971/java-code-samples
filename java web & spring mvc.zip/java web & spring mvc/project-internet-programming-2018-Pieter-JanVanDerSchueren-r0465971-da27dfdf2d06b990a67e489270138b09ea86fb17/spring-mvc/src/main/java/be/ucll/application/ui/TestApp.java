package be.ucll.application.ui;

import be.ucll.application.db.DbException;
import be.ucll.application.db.ShopFacade;
import be.ucll.application.domain.DomainException;
import be.ucll.application.domain.Product;

import javax.swing.JOptionPane;

public class TestApp {

    public static void main(String[] args) {
        ShopFacade shop = new ShopFacade("memory");
        String input = null;
        Boolean error;
        String dbtype = "memory";
        String productId;
        String name;
        String description;
        String price;

        do {
            try {
                dbtype = JOptionPane.showInputDialog("Geef het type database dat je wil gebruiken: " + "\"file\", " + "\"memory\" of " + "\"sql\"" + ".");
                shop.setStrategy(dbtype);
                error = false;
            } catch (DbException e) {
                JOptionPane.showMessageDialog(null, e.getMessage());
                error = true;
            }
        } while (error);


        do {
            do {
                try {
                    input = JOptionPane.showInputDialog("Welkom bij testapplicatie!"
                            + "\n Je maakt gebruik van een " + dbtype + "database!"
                            + "\n\n 1. Maak een nieuwe product aan en voeg die toe aan je DB." +
                            " \n 2. Verwijder een product" +
                            " \n 3. Wijzig een product" +
                            " \n 4. Print de gegevens van alle producten in je lijst op de console." +
                            " \n 5. Geef de som van de prijs van alle producten" +
                            " \n 6. Reset db" +
                            " \n 7. Kies een andere DB" +
                            " \n\n 0. Afsluiten");
                    error = false;
                    if (input == null || input.trim().isEmpty()) {
                        input = "0";
                    } else if (Integer.parseInt(input) > 7 || Integer.parseInt(input) < 0) {
                        JOptionPane.showMessageDialog(null, "Verkeerde input!");
                        error = true;
                    }
                } catch (Exception e) {
                    error = true;
                }
            } while (error);

            if (Integer.parseInt(input) == 1) {
                do {
                    input = JOptionPane.showInputDialog("\n Geef de name.");
                    name = input;
                    input = JOptionPane.showInputDialog("\n Geef de description.");
                    description = input;
                    input = JOptionPane.showInputDialog("\n Geef de price.");
                    price = input;
                    try {
                        shop.addProduct(new Product(name, description, price));
                        error = false;
                    } catch (DomainException e) {
                        JOptionPane.showMessageDialog(null, e.getMessage());
                        error = true;
                    }
                } while (error);

            } else if (Integer.parseInt(input) == 2) {
                do {
                    input = JOptionPane.showInputDialog("Geef de productId van het te verwijderen product");
                    productId = input;
                    if (input != null) {
                        try {
                            shop.deleteProduct(Integer.parseInt(productId));
                            error = false;
                        } catch (DbException e) {
                            JOptionPane.showMessageDialog(null, e.getMessage());
                            error = true;
                        }
                    } else if (input == null) {
                        error = false;
                        input = "1";
                    }
                } while (error);

            } else if (Integer.parseInt(input) == 3) {
                do {
                    input = JOptionPane.showInputDialog("Geef de productId van het te wijzigen product");
                    productId = input;
                    input = JOptionPane.showInputDialog("\n Geef de name.");
                    name = input;
                    input = JOptionPane.showInputDialog("\n Geef de description.");
                    description = input;
                    input = JOptionPane.showInputDialog("\n Geef de price.");
                    price = input;
                    try {
                        shop.updateProduct(new Product(productId, name, description, price));
                        error = false;
                    } catch (Exception e) {
                        JOptionPane.showMessageDialog(null, e.getMessage());
                        error = true;
                    }
                } while (error);

            } else if (!input.isEmpty() && Integer.parseInt(input) == 4) {
                System.out.println("\nDe producten in de lijst zijn: \n");
                try {
                    shop.toConsole();
                } catch (DbException e) {
                    System.out.println(e.getMessage());
                }
                System.out.println("\n");
            } else if (!input.isEmpty() && Integer.parseInt(input) == 5) {
                try {
                    System.out.println("\nDe som van alle producten in de lijst is: " + shop.calculatedValue() + "\n\n");
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
            } else if (!input.isEmpty() && Integer.parseInt(input) == 6) {
                try {
                    shop.resetDb();
                } catch (Exception e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
            } else if (!input.isEmpty() && Integer.parseInt(input) == 7) {
                try {
                    shop.quit();
                } catch (DbException e) {
                    JOptionPane.showMessageDialog(null, e.getMessage());
                }
                do {
                    try {
                        dbtype = JOptionPane.showInputDialog("Geef het type database dat je wil gebruiken: " + "\"file\", " + "\"memory\" of " + "\"sql\"" + ".");
                        shop.setStrategy(dbtype);
                        error = false;
                    } catch (DbException e) {
                        JOptionPane.showMessageDialog(null, e.getMessage());
                        error = true;
                    }
                } while (error);
            }
        } while (Double.parseDouble(input) != 0);
        try {
            shop.quit();
        } catch (DbException e) {
            JOptionPane.showMessageDialog(null, e.getMessage());
        }
    }
}