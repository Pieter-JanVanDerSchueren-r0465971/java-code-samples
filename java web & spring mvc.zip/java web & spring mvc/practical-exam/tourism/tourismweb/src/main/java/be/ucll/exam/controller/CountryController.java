package be.ucll.exam.controller;

import be.ucll.exam.service.TourismService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping(value = "/country")
public class CountryController {
    private final TourismService service;

    public CountryController(@Autowired TourismService service) {
        this.service = service;
    }

    public ModelAndView getCountries() {
        ModelAndView mav = new ModelAndView("read", "countries", service.getCountries());
        return mav;
    }
}
